﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Toplam: " + (Convert.ToInt16(textBox1.Text) + Convert.ToInt16(textBox2.Text)));


            //if (Convert.ToInt16(textBox1.Text) > 100 || Convert.ToInt16(textBox2.Text) > 100 || Convert.ToInt16(textBox3.Text) > 100 || Convert.ToInt16(textBox1.Text) < 0 || Convert.ToInt16(textBox2.Text) < 0 || Convert.ToInt16(textBox3.Text) < 0)
            //{
            //    MessageBox.Show("Değerler düzgün girilmedi", "", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            //}
            //else
            //{
            //    int sinav1 = Convert.ToInt16(textBox1.Text);
            //    int sinav2 = Convert.ToInt16(textBox2.Text);
            //    int sinav3 = Convert.ToInt16(textBox3.Text);
            //    MessageBox.Show("Ortalamanız: " + (sinav1 + sinav2 + sinav3) / 3, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

               
            //}
        }







        private void Form1_Load(object sender, EventArgs e)
        {
            
            button2.FlatStyle = FlatStyle.Flat;
            button3.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderSize = 0;
            button2.BackColor = Color.White;
            button3.BackColor = Color.White;
            button3.FlatAppearance.MouseOverBackColor = Color.Red;
            


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Çarpım: " + Convert.ToInt16(textBox1.Text) * Convert.ToInt16(textBox2.Text));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Çıkarma: " + (Convert.ToInt16(textBox1.Text) - Convert.ToInt16(textBox2.Text)));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Bölme: " + Convert.ToInt16(textBox1.Text) / Convert.ToInt16(textBox2.Text));
        }

       

        private void button3_Leave(object sender, EventArgs e)
        {
            
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            button3.ForeColor = Color.White;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.ForeColor = Color.Black;
        }
    }
}
